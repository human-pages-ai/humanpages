# HumanPages Project Configuration for spec-dev

This file configures the `spec-dev` skill for the HumanPages.ai codebase. Read this BEFORE implementing any spec.

---

## 1. Mandatory Pre-Reads

Read these files at the start of every session, in this order:

1. **`CLAUDE.md`** (project root) — Master development rules. Overrides everything.
2. **`shared/profile-schema.json`** — Single source of truth for all profile fields, enums, wizard steps.
3. **`specs/README.md`** — Build order, dependency graph, key principles, session workflow.
4. **The specific spec file** (`specs/XX-feature-name.md`)

---

## 2. Git Workflow

### Branch Creation

The repo has a built-in session script. ALWAYS use it:

```bash
sh scripts/git-session.sh <feature-name>
```

This creates `session/<YYYYMMDD-HHMMSS>-<feature-name>` off latest master, stashes uncommitted changes, and isolates your work.

### Branch Names per Spec

| Spec | Command |
|------|---------|
| 01 | `sh scripts/git-session.sh rate-limit-overhaul` |
| 02 | `sh scripts/git-session.sh jury-system` |
| 03 | `sh scripts/git-session.sh open-job-posting` |
| 04 | `sh scripts/git-session.sh result-delivery` |
| 05 | `sh scripts/git-session.sh erc8004-bridge` |
| 06 | `sh scripts/git-session.sh online-now-signal` |
| 07 | `sh scripts/git-session.sh bulk-jobs` |

### Rules

- NEVER commit to master
- NEVER use `--no-verify` to skip pre-push hooks
- Do NOT push to remote — human reviews first
- If sub-agents need to edit code, use `isolation: "worktree"`
- Before editing, run `git status` to verify clean working tree

### Known Pre-Push Hook Issues

| Issue | Fix |
|-------|-----|
| `Cannot find module '.prisma/client/default'` | Add resolve alias in `backend/vitest.config.ts` |
| e2e timeout during parallel tests | `PUSH_LITE=1 git push` to skip e2e |
| Flaky RouteGuards tests | Known flake — re-run |

---

## 3. Codebase Architecture

### Stack

- **Backend:** Express + TypeScript, Prisma ORM (v7), PostgreSQL, Vitest
- **Frontend:** React + TypeScript, Vite
- **Blockchain:** Viem (payment verification), Superfluid (streaming)
- **Auth:** JWT (humans), API key + bcrypt (agents), OAuth 2.0 (MCP)
- **Payments:** USDC on Ethereum, Base, Polygon, Arbitrum, Optimism + x402 protocol

### Directory Map

```
backend/
  src/
    routes/         # 45+ route files (jobs.ts, humans.ts, agents.ts, etc.)
    middleware/      # Auth, rate limiting, x402
    lib/            # Business logic, blockchain, notifications
      blockchain/   # verify-payment.ts, chains.ts, Superfluid
    cron/           # Scheduled tasks
    tests/          # 47 test files, per-process ephemeral DBs
      helpers.ts    # cleanDatabase(), createActiveTestAgent(), createTestUser()
      setup.ts      # Per-worker DB creation, Prisma migration
  prisma/
    schema.prisma   # 1894 lines — THE data model
  vitest.config.ts  # pool: 'forks', up to 8 workers

frontend/
  src/
    pages/          # 32 pages
    components/     # 32 component directories
    lib/api.ts      # API client
    hooks/

shared/
  profile-schema.json  # Single source of truth for profile fields + enums

mcp-server/            # MCP tool definitions

scripts/
  git-session.sh       # Create isolated session branch
  git-session-merge.sh # Merge session back to master
```

### Key Files Reference

| File | When to Read |
|------|-------------|
| `backend/prisma/schema.prisma` | Before adding any model or field |
| `backend/src/routes/jobs.ts` | For any job-related feature |
| `backend/src/routes/humans.ts` | For search or profile features |
| `backend/src/routes/agentActivation.ts` | For tier-related changes |
| `backend/src/middleware/x402PaymentCheck.ts` | If touching rate limits or gating |
| `backend/src/lib/blockchain/verify-payment.ts` | For any payment feature |
| `backend/src/tests/helpers.ts` | Before writing any tests |
| `backend/src/app.ts` | When registering new routes |
| `backend/src/lib/mcp-tools.ts` | When adding MCP tools |
| `frontend/src/lib/api.ts` | When adding API client methods |

---

## 4. The Three-Layer Sync Rule (CRITICAL)

Every field must match across ALL of these. Missing one layer is a data-loss bug:

1. **Prisma schema** → `backend/prisma/schema.prisma`
2. **Backend Zod validation** → `backend/src/routes/*.ts` (createJobSchema, updateProfileSchema, etc.)
3. **Frontend types** → `frontend/src/pages/onboarding/types.ts`
4. **Frontend form state** → `frontend/src/pages/onboarding/hooks/useProfileForm.ts`
5. **Frontend submit payload** → `frontend/src/pages/onboarding/index.tsx` (handleFinalSubmit)
6. **Frontend API client** → `frontend/src/lib/api.ts`

After adding/changing any field, walk through all 6 layers and verify sync.

---

## 5. Testing Infrastructure

### How Tests Work

- **Framework:** Vitest, `pool: 'forks'`, up to 8 parallel workers
- **Database:** Each worker creates its own ephemeral PostgreSQL DB (`humans_test_<pid>_<timestamp>`)
- **Setup:** `backend/src/tests/setup.ts` handles DB creation/migration/teardown
- **Helpers:** `backend/src/tests/helpers.ts` — always use these, don't manually insert

### Test Helpers Available

```typescript
cleanDatabase()                    // Delete all records (FK-safe order)
createTestUser(overrides?)         // Create human + JWT token
createActiveTestAgent(overrides?)  // Create agent with API key
```

### Running Tests

```bash
cd backend && npm test              # Full suite
cd backend && npx vitest run src/tests/<file>.test.ts  # Single file
cd backend && npm run build         # TypeScript compilation
```

### Test Conventions

- Use `cleanDatabase()` in `beforeEach`
- Test files: `backend/src/tests/<feature>.test.ts`
- Flow tests: `backend/src/tests/flows/<feature>.test.ts`
- Reference `shared/profile-schema.json` for valid enum values
- `NODE_ENV === 'test'` is auto-set — rate limiters already skip in test

### After Adding New Models

Update `cleanDatabase()` in `helpers.ts` with new models in the correct FK-safe deletion order.

---

## 6. Prisma Migration Workflow

```bash
# 1. Edit backend/prisma/schema.prisma
# 2. Generate client:
cd backend && npx prisma generate
# 3. Create migration:
cd backend && npx prisma migrate dev --name <descriptive-name>
```

**Pitfall:** `prisma migrate dev` may auto-generate a `*_init` migration that conflicts. Delete it and re-run with an explicit name.

---

## 7. Existing Enums (use exact values)

From `shared/profile-schema.json`:

- **RateType**: `HOURLY`, `FLAT_TASK`, `PER_WORD`, `PER_PAGE`, `NEGOTIABLE`
- **WorkType**: `digital`, `physical`, `both`
- **PaymentPreference**: `UPFRONT`, `ESCROW`, `UPON_COMPLETION`, `STREAM`
- **WorkMode**: `REMOTE`, `ONSITE`, `HYBRID`
- **JobStatus**: `PENDING`, `ACCEPTED`, `PAYMENT_CLAIMED`, `PAID`, `STREAMING`, `PAUSED`, `SUBMITTED`, `COMPLETED`, `CANCELLED`, `DISPUTED`, `REJECTED`
- **AgentStatus**: `PENDING`, `ACTIVE`, `SUSPENDED`, `BANNED`
- **ActivationTier**: `BASIC`, `PRO` (spec 01 adds `WHALE`)

When adding new enums, update `shared/profile-schema.json` too.

---

## 8. Agent Tiers (current)

```
BASIC:  1 job offer per 2 days,  1 profile view/day,  no follower requirement
PRO:   15 job offers per day,   50 profile views/day, requires 1000+ followers
```

Activation paths: AUTO (first 100 free PRO), SOCIAL (post verification), PAYMENT (on-chain), ADMIN (manual).

---

## 9. x402 Payment Protocol

Agents bypass ALL tier limits by paying per-request:

| Resource | Price |
|----------|-------|
| Profile view | $0.05 |
| Job offer | $0.25 |
| Listing post | $0.50 |

Network: Base (eip155:8453). Middleware chain: `ipRateLimiter → x402PaymentCheck → authenticateAgent → requireActiveOrPaid → handler`

MUST be preserved in all features touching rate limits or gating.

---

## 10. Privacy Rules

- `publicHumanSelect` in `humans.ts` NEVER includes: name, email, phone, whatsapp, sms, telegram, telegramChatId, notification preferences, OAuth IDs, passwordHash
- Name masked as "FirstName L." on public profiles
- Bio sanitized by `sanitizeBio()` (strips name, email, phone)
- Notification flags aggregated to `channelCount` for public display

---

## 11. Common Pitfalls

1. **priceUnit mismatch**: Frontend sends `"per hour"`, backend expects `"HOURLY"`. UNIT_MAP in `services.ts` handles transform.
2. **Education year fields**: Use `startYear`/`endYear`, not legacy `year`.
3. **Languages format**: `"Language (Proficiency)"` strings, not ISO codes.
4. **Equipment format**: `"Category - Tool"` or just category.
5. **Prisma migrations**: Delete auto-generated `*_init` migration, re-run.
6. **SPA + OG tags**: Pages needing OG previews need server-side injection in `backend/src/lib/seo.ts`.
7. **English-only pages**: `/dev/*`, `/dev/connect/*`, `/prompt-to-completion` — no `/:lang` prefix.

---

## 12. Ecosystem Context

HumanPages is part of a multi-platform ecosystem. Features should connect where applicable:

- **Moltbook** — Agent social network with karma system. Jury verdicts post here. Karma feeds jury weighting.
- **AgentFlex** — Agent rankings at agentflex.vip. Jury earnings, completion rates, tier info displayed here.
- **ERC-8004** — On-chain agent reputation standard on Base. Reviews already pre-compute ERC-8004 fields.
- **Moltbook Solver** — HumanPages API solving Moltbook's math challenges for agents (50/day free).

---

## 13. Business Context

- **Product:** MCP-native marketplace where AI agents hire humans for $2-5 micro-tasks
- **Payment:** USDC only, 0% fees (revenue from premium subscriptions + x402)
- **Target users (clients):** Vibe-coders, crypto traders, Web3 devs, mobile devs, Russian crypto users
- **Competitors:** RentAHuman, HumanAPI (live), MTurk, Fiverr (potential MCP)
- **Advantage:** MCP-native, crypto-settled, zero fees, borderless, no middlemen
- **Stage:** Live but chicken-and-egg. 25K BTCMap listings, most un-enriched. Active outreach pipeline.

---

## 14. Additional Review Roles for HumanPages

Beyond the generic spec-dev roles, HumanPages specs may include:

| Role | Focus |
|------|-------|
| **Ecosystem Architect** | Moltbook/AgentFlex/ERC-8004 integration, cross-platform data flow |
| **SEO Specialist** | OG tags, server-side meta injection, structured data, sitemap |
| **Smart Contract Auditor** | On-chain interactions, gas efficiency, re-entrancy, wallet security |
| **Data Scientist** | Scoring algorithms, statistical validity, consensus methods |
| **Infrastructure Engineer** | Redis, cron jobs, storage (R2/S3), monitoring |
| **DevOps Engineer** | Deployment, env vars, health checks, CI/CD |

---

## 15. Customer Personas for Enhancement Round

When Step 5a of spec-dev asks for customer personas, use these 10 archetypes (from the War Room evaluation). Pick 5 that are most relevant to the specific feature:

| Persona | Description | What They Care About |
|---------|-------------|---------------------|
| **Vibe-Coder** | Uses Claude/Cursor to build side projects, delegates tasks they can't automate | Speed, simplicity, "it just works", cheap micro-tasks |
| **Mobile App Dev** | Builds iOS/Android apps, needs manual QA testing on real devices | Device-specific testers, screenshot delivery, fast turnaround |
| **Crypto Trader** | Automates trading workflows, needs manual verification of DeFi positions | Real-time availability, accuracy, 24/7 workers, crypto-native payments |
| **Web3 Developer** | Builds dApps, smart contracts, needs human testing/review | On-chain reputation, privacy, decentralized trust, no KYC |
| **Russian Crypto User** | Operates in sanctioned/restricted markets, uses crypto to bypass banking | Borderless, no KYC, USDC settlement, Russian-speaking workers |
| **AI Automation Builder** | Builds complex multi-agent workflows, delegates human-in-the-loop steps | MCP-native tools, structured results, bulk operations, API reliability |
| **DeFi Power User** | Manages multiple protocols, needs manual monitoring/verification | Sub-$5 tasks, fast claim times, crypto-only payments |
| **Content Creator with AI** | Uses AI for content, needs human editing/fact-checking/localization | Quality, language diversity, revision workflow, creative judgment |
| **E-Commerce Crypto Merchant** | Runs online store accepting crypto, needs product/service tasks | Reliability, dispute resolution, cost predictability |
| **Privacy-Conscious Dev** | Values anonymity, avoids platforms that harvest data | No PII exposure, on-chain verification, minimal data collection |

---

## 16. Visual Preview Styling

When generating HTML previews and infographics (Steps 5b and 5c of spec-dev), use this branding:

### Color Palette
- **Primary:** `#7C3AED` (purple — HumanPages brand)
- **Background:** `#0F172A` (dark slate)
- **Surface:** `#1E293B` (slightly lighter slate)
- **Accent:** `#22D3EE` (cyan — for highlights and CTAs)
- **Success:** `#10B981` (green)
- **Warning:** `#F59E0B` (amber)
- **Error:** `#EF4444` (red)
- **Text:** `#F8FAFC` (near-white)
- **Text muted:** `#94A3B8` (gray-400)

### Style Guidelines
- Use Tailwind CDN (`<script src="https://cdn.tailwindcss.com"></script>`)
- Dark theme always (matches the product aesthetic)
- Clean, minimal — think Stripe/Linear dashboard, not enterprise software
- Use system fonts: `-apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif`
- Icons: use Unicode symbols or simple SVG, no external icon libraries
- Responsive: must look good on both desktop and mobile

### CTO Overview Template Structure
The infographic for the CTO should follow this layout:
1. **Header bar** — Feature name + one-liner + ship date (purple gradient background)
2. **Metrics strip** — 3-4 key numbers in big bold cards (horizontally)
3. **Before/After** — Two-column visual comparison
4. **Architecture diagram** — New/modified models + API endpoints (box diagram)
5. **Risk dashboard** — Color-coded indicators for breaking changes, security, perf, deploy complexity
6. **Dependencies + Timeline** — Where this fits in the roadmap
7. **Footer** — "Generated by spec-dev" + timestamp

---

## 17. Real-World Action Context

When generating real-world action suggestions (Step 5d of spec-dev), use this context about available channels and assets:

### Marketing Channels Available
- **Twitter/X:** @humanpages (crypto/AI audience)
- **Moltbook:** Agent social network (can post announcements via agent accounts)
- **AgentFlex:** Can update rankings/leaderboards to highlight new features
- **University outreach pipeline:** Active partnerships for freelancer recruitment
- **BTCMap community:** 25K+ business network with contact pipeline
- **Crypto forums:** Reddit r/cryptocurrency, r/defi, Bitcointalk
- **Dev communities:** Hacker News, DEV.to, Claude/MCP Discord channels

### Content Team Resources
- Can create blog posts, Twitter threads, demo videos
- Product has a `/blog` section on the website
- Can create landing pages for specific features

### Budget Reference Points
- $0/mo = founder's time only, organic reach, community engagement
- $100/mo = sponsored posts, small ad budget, tooling subscriptions
- $1000/mo = content creator partnerships, targeted ads, event sponsorship
- $5000+/mo = influencer partnerships, conference presence, PR agency

---

## 18. Linear Workspace Configuration

When Step 0c creates Linear tracking issues, use these settings:

### Workspace Details
- **Team:** Look for a team named "HumanPages" or "Engineering" (query via `list_teams`)
- **Project:** Look for a project matching the current phase (e.g., "Phase 1", "Q2 2026") or create issues without a project

### Label Conventions
- `spec-dev` — all issues created by this skill
- `feature` — new feature implementations
- `bug-fix` — fixes found during review rounds
- `enhancement` — improvements from Step 5a customer feedback
- `phase-1` / `phase-2` / `phase-3` — matches the spec's build phase
- Domain labels: `backend`, `frontend`, `blockchain`, `infra`, `mcp`

### Priority Mapping
- Phase 1 specs (01, 02) → **Urgent**
- Phase 2 specs (03, 04) → **High**
- Phase 3 specs (05, 06, 07) → **Normal**
- Enhancement round improvements → **Low**

### Issue Description Template
```
**Spec:** specs/XX-feature-name.md
**Branch:** session/YYYYMMDD-HHMMSS-feature-name
**Estimated effort:** [from spec]
**Dependencies:** [from spec]

### Acceptance Criteria
[Copied from spec]
```

---

## 19. Generated Artifact Directories

The spec-dev skill generates several artifact types. Store them in these locations:

| Artifact | Directory | Naming Convention |
|----------|-----------|-------------------|
| Frontend preview | `specs/previews/` | `XX-feature-name-preview.html` |
| Schema preview | `specs/previews/` | `XX-feature-name-schema.html` |
| CTO overview | `specs/previews/` | `XX-feature-name-overview.html` |
| Release notes | `specs/release-notes/` | `XX-feature-name.md` |
| Monitoring checklist | `specs/monitoring/` | `XX-feature-name-monitoring.md` |
| Load test scripts | `specs/load-tests/` | `XX-feature-name.k6.js` |
| CHANGELOG | `CHANGELOG.md` | (project root, append to existing) |

Create these directories if they don't exist. Git-ignore generated HTML previews if they contain mock data.

---

## 20. War Room Integration

When Step 5e triggers (high-risk features), these HumanPages specs qualify as high-risk:

| Spec | Why High-Risk |
|------|--------------|
| 01 - Rate Limit Overhaul | Changes middleware chain, all agents affected |
| 02 - Jury System | Touches payments ($0.01/verdict payouts), data integrity |
| 04 - Result Delivery | File uploads, auto-approve timer, payment release |
| 05 - ERC-8004 Bridge | On-chain writes, gas costs, smart contract interaction |

Specs 03, 06, 07 are lower risk and can skip the war room unless the implementation introduces unexpected complexity.

When invoking `/war`, include the x402 middleware chain context — any feature that changes rate limiting or gating MUST preserve the `ipRateLimiter → x402PaymentCheck → authenticateAgent → requireActiveOrPaid → handler` order.

---

## 21. Monitoring Dashboard Conventions

When Step 5h builds a monitoring dashboard, follow these HumanPages-specific patterns:

### Where dashboards live
- **Admin panel route:** `/dev/admin` (English-only, no `/:lang` prefix)
- **Backend endpoints:** `backend/src/routes/admin.ts` — add a new stats endpoint following the existing pattern
- **Frontend components:** `frontend/src/pages/dev/admin/` — each feature gets its own component file
- **Navigation:** Add a new tab to the existing admin dashboard tabs array

### Existing dashboard sections to reference
Read 1-2 of these before writing new dashboard code to match the style:
- Active users chart (the most complete example — has DAU/WAU/MAU toggle, stacked bars, KPI row)
- Vouch system stats
- Signup funnel

### Shared helpers
Import from the existing shared admin helpers file — don't duplicate `fmt()`, `pct()`, `safeDiv()`, `formatDate()`, etc.

### Auth
All admin endpoints use `authenticateToken` + `requireAdmin` middleware. Never add a stats endpoint outside this auth chain.

### Key segments for HumanPages dashboards
Most features should break down by:
- **Agent tier:** BASIC / PRO / WHALE
- **Payment method:** x402 per-request vs subscription
- **Geography:** top 5 countries (from human profiles)

### PostHog integration
If the feature fires analytics events (Phase G), query them server-side via the PostHog query API. Never expose the PostHog API key to the frontend. Use the existing `queryPostHog()` helper in `backend/src/lib/`.
