---
name: spec-dev
description: |
  Spec-driven feature development with virtual dev team review. Use this skill whenever the user asks to implement a feature from a spec file, build something from a spec, work on a feature spec, or mentions "implement spec", "build from spec", "start feature session", "work on spec 01/02/03", or any reference to implementing features described in markdown spec files. Also trigger when the user says "implement the rate limit overhaul", "build the jury system", "start the open job posting feature", or similar — any request to build a specific named feature that has a corresponding spec file. This skill handles the full lifecycle: branch creation, phased implementation, automated testing, multi-round virtual dev team review with self-correction, and final verification.
---

# Spec-Driven Feature Development

You are implementing a feature from a specification file. This skill guides you through a disciplined, phased process with a virtual dev team that reviews your work across multiple rounds — catching issues and self-correcting before the human ever needs to intervene.

## Step -1: Determine Complexity Tier

Before anything else, read the spec and classify the feature into one of three tiers. This determines how much of the pipeline you run — a 2-hour config tweak doesn't need persona simulations and load test scripts.

| Tier | Criteria | Examples |
|------|----------|----------|
| **Light** | ≤1 day effort, no new DB models, no new API routes, touches ≤5 files | Config changes, rate limit tweaks, env var additions, copy updates, bug fixes |
| **Standard** | 1 day–1 week, new models or endpoints, frontend + backend changes | New API feature, new UI page, new middleware, moderate refactors |
| **Heavy** | >1 week, new subsystem, touches payments/auth/infra, other specs depend on it | Jury system, ERC-8004 bridge, file upload system, bulk operations |

### What each tier runs:

| Step | Light | Standard | Heavy |
|------|-------|----------|-------|
| 0: Load Context | ✓ | ✓ | ✓ |
| 0b: Competitive Research | skip | ✓ | ✓ |
| 0c: Linear Tracking | skip | ✓ | ✓ |
| 1: Branch | ✓ | ✓ | ✓ |
| 2: Plan | simplified (phases A-C only) | full | full |
| 3: Implement | ✓ | ✓ | ✓ |
| 4: Dev Team Review | 1 round only (senior reviewer) | 2 rounds | 3 rounds |
| 5a: Customer Personas | skip | 3 personas | 5 personas |
| 5b: Visual Previews | skip | backend schema only | full (frontend + backend) |
| 5c: CTO Overview | skip | ✓ | ✓ |
| 5d: Action Suggestions | skip | 2 budget tiers ($0, $100) | all 4 tiers |
| 5e: War Room | skip | skip | ✓ (if high-risk criteria met) |
| 5f: Changelog | ✓ (entry only, no release note file) | ✓ | ✓ |
| 5g: Load Testing | skip | flag N+1 queries only | full k6 scripts |
| 5h: Monitoring Dashboard | metric definitions + stub endpoint | full dashboard | full dashboard + segment breakdowns |
| 6: Final Verification | simplified checklist | full | full + cross-feature regression |
| 7: Report | short format | standard format | full format with all artifacts |

**How to classify:** Check the spec's "Estimated effort" field first. If absent, count: new Prisma models + new API routes + new frontend pages. 0 = Light, 1-3 = Standard, 4+ = Heavy. When in doubt, go one tier up.

The human can override the tier at any time ("run the full pipeline on this" or "keep it light").

---

## Step 0: Load Project Context

Before touching any code, load the project-specific configuration. Look for a project config file — the spec or the user will tell you where it is, or check for a `project-config.md` or `humanpages.md` (or similar) in the skill's `references/` directory or in the project's `specs/` folder.

The project config tells you:

- **Codebase rules file** (e.g., `CLAUDE.md`) — read this first, it overrides everything
- **Schema source of truth** (e.g., `shared/profile-schema.json`) — read before modifying any data model
- **Git workflow** — how to create branches, what's forbidden
- **Test infrastructure** — how tests work, helpers available, how to run them
- **Layer sync rules** — which files must stay in sync when you change a model
- **Known pitfalls** — project-specific gotchas to avoid

**If no project config exists**, ask the user for: (1) where specs live, (2) how to create branches, (3) how to run tests, (4) any codebase rules files to read.

Then read the spec file the user wants implemented.

## Step 0b: Competitive & Prior Art Research

Before writing a single line, spend 5 minutes understanding how others have solved this problem. This prevents reinventing the wheel and surfaces patterns you'd otherwise miss.

1. **Web search** for how competitors and similar platforms handle this feature. Search for: `"[feature name] API design"`, `"[feature name] implementation"`, `"[competitor name] [feature]"`. Read 2-3 relevant results.

2. **Check open-source implementations.** Search GitHub for similar features in comparable projects (marketplaces, gig platforms, payment systems). Note any patterns worth adopting.

3. **Document findings** in a brief section at the top of your implementation plan:
   ```
   ## Prior Art
   - [Competitor/project] does X — we'll adopt Y from their approach
   - [Library/pattern] is the standard way to handle Z
   - Decided NOT to follow [approach] because [reason]
   ```

This takes 5 minutes but saves hours of rework when you discover mid-implementation that there's a standard pattern you should have followed.

## Step 0c: Create Linear Tracking (if Linear is connected)

If the project uses Linear (check for Linear MCP tools), create a tracking issue for this feature:

1. **Create a parent issue** for the feature with:
   - Title: `[Spec XX] Feature Name`
   - Description: The spec's "Why This Matters" section + acceptance criteria
   - Priority: Based on the spec's phase (Phase 1 = Urgent, Phase 2 = High, Phase 3 = Normal)
   - Labels: `spec-dev`, `feature`, and any relevant domain labels

2. **Create sub-issues** for each implementation phase:
   - `[Spec XX] Phase A: Data Model`
   - `[Spec XX] Phase B: Backend Logic`
   - `[Spec XX] Phase C: Tests`
   - `[Spec XX] Phase D: Frontend`
   - `[Spec XX] Phase E: Integration`
   - `[Spec XX] Dev Team Review`
   - `[Spec XX] Enhancement Round`

3. **Update issue status** as you progress through each phase. Move to "In Progress" when starting, "Done" when complete.

This creates a paper trail the whole team can follow, and the CTO can check Linear instead of asking for status updates.

## Step 1: Create Isolated Branch

Every feature gets its own branch. Never commit to the main/master branch.

Use the project config's branching instructions. Typical pattern:

```bash
# If project has a session script:
sh scripts/git-session.sh <feature-name>

# Otherwise:
git checkout -b feature/<feature-name> main
```

Verify: `git branch --show-current` should show your new branch, not main/master.

## Step 2: Plan the Implementation

Before writing code, create a phased implementation plan. The recommended order (adapt based on project config):

### Phase A: Data Model
1. Add/modify database schema (Prisma, SQL, etc.)
2. Generate migration
3. Update any schema source-of-truth files
4. Update test helpers (e.g., `cleanDatabase()` deletion order)

### Phase B: Backend Logic
1. Create route handlers / API endpoints
2. Add validation schemas (Zod, Joi, etc.)
3. Add middleware if needed
4. Wire routes into the app

### Phase C: Tests
1. Write unit tests for new logic
2. Write integration tests for API endpoints
3. Write flow tests for multi-step scenarios
4. Run full test suite — fix any failures

### Phase D: Frontend
1. Create page components
2. Create reusable UI components
3. Update API client
4. Add routes

### Phase E: Integration Points
1. Update MCP tools / SDK / CLI if applicable
2. Update any ecosystem integrations mentioned in the spec
3. Add cron jobs if needed

### Phase F: Feature Flag & Rollback Strategy

Every feature should be shippable behind a flag so it can be turned off instantly if something goes wrong in production.

1. **Add a feature flag** — use environment variables (simplest) or the project's feature flag system. Example: `FEATURE_JURY_SYSTEM_ENABLED=true`. Gate the new functionality behind this flag so the old behavior is the default.
2. **Document the rollback plan** — in a code comment at the feature flag check, write exactly what happens if the flag is turned off: which endpoints return 404, which UI elements hide, which cron jobs skip.
3. **Database rollback** — if you added new tables/columns, ensure the feature works even if those tables are empty (graceful degradation). Never make the old code path depend on new schema.

### Phase G: Observability

Code you can't observe is code you can't debug in production.

1. **Structured logging** — Add log statements at key decision points using the project's logger (not `console.log`). Include: action name, actor ID, relevant IDs, outcome. Example: `logger.info({ action: 'jury_vote_committed', disputeId, jurorId, phase: 'commit' })`
2. **Metrics / analytics events** — Identify the 3-5 key events that indicate this feature is working. Add PostHog/analytics tracking calls. Examples: `feature_used`, `feature_error`, `feature_completed`.
3. **Error handling with context** — Every catch block should log the error with enough context to debug without reproducing: request params, user/agent ID, what step failed.
4. **Health check** — If the feature adds a cron job or background process, add a health check endpoint or log entry that confirms it's running.

### Phase H: Layer Sync Verification
1. Walk through every sync rule from the project config
2. Verify every new field/enum exists in ALL required layers
3. Check that no layer was missed

Create a TodoList from this plan, customized to the specific spec.

## Step 3: Implement

Work through each phase methodically. For each phase:

1. Mark the todo as in-progress
2. Implement the changes
3. Run tests after each phase (not just at the end)
4. Fix any issues before moving to the next phase
5. Mark complete

### Implementation Guidelines

- **Follow existing patterns.** Read 2-3 similar files in the codebase before writing new ones. Match the style, naming, imports, and structure.
- **Validate all inputs.** Every API endpoint gets a validation schema. No raw `req.body` access.
- **Handle errors explicitly.** No swallowed errors. Use the project's error handling patterns.
- **Write tests as you go.** Don't defer all tests to the end — write them alongside the code they test.
- **Commit frequently.** One commit per phase is a good cadence. Descriptive messages.

## Step 4: Dev Team Review (3 Rounds)

This is the core quality mechanism. After implementation is complete, run a thorough review process with 3 rounds of increasing rigor. Each round catches issues the previous round missed, and you self-correct between rounds.

### How the Review Works

The spec file contains a **Dev Team Review Checklist** with items grouped by role (Architect, QA, UX, Frontend, Backend, etc.). If the spec doesn't have one, use the default roles below.

### Default Review Roles

| Role | Focus Area |
|------|-----------|
| **Architect** | Data model relationships, transaction safety, scalability, no circular dependencies, proper separation of concerns |
| **QA** | Every test in the spec is written and passing, edge cases covered, error paths tested, boundary conditions checked |
| **UX** | Error messages are clear and actionable, mobile responsiveness, loading states, empty states, accessibility |
| **Frontend** | Component reusability, responsive layout, state management patterns, no prop drilling, proper loading/error states |
| **Backend** | Validation schemas complete, query performance (indexed?), middleware chain correct, auth on all endpoints, no PII leaks |
| **Security** | Auth checked on every endpoint, no PII in public responses, input sanitization, rate limiting, CORS |
| **User Feedback** | Key metrics identified, analytics events added, success criteria measurable |
| **Product Manager** | Feature aligns with business model, premium/upgrade opportunities identified, competitive positioning clear |
| **Critical 3rd-Party Reviewer** | Would an external auditor flag anything? Compliance, legal, data handling |
| **Tech Blogger** | Can this be explained in a changelog? Is the narrative clear? |

### Round 1: Self-Review (thorough)

Walk through EVERY checklist item from the spec. For each item:

1. Check if the code satisfies it
2. If YES: mark it done
3. If NO: fix the issue immediately, then mark done
4. If UNCLEAR: flag for Round 2

Spawn sub-agents for the 3 most critical roles (typically **Architect**, **QA**, and **Security**). Each sub-agent receives:

```
You are the [ROLE] reviewer for a feature implementation.

=== SPEC ===
[The full spec content]

=== FILES CHANGED ===
[git diff output showing all changes]

=== YOUR CHECKLIST ===
[The checklist items for your role from the spec]

Review each checklist item. For each:
- PASS: The code satisfies this requirement. One sentence explaining why.
- FAIL: The code does NOT satisfy this. Explain exactly what's wrong and how to fix it.
- WARN: The code partially satisfies this. Explain the gap.

Be specific. Reference file names, line numbers, and function names.
End with a summary: X PASS, Y FAIL, Z WARN.
```

### Round 1 → Self-Correction

Read all sub-agent reviews. Fix every FAIL item. Address every WARN. Then:
- Re-run tests to make sure fixes didn't break anything
- Commit the fixes: `"fix: address Round 1 review feedback"`

### Round 2: Cross-Check Review

Spawn sub-agents again, but this time they see Round 1's findings and your fixes:

```
You are the [ROLE] reviewer, Round 2. In Round 1, these issues were found and fixed:

=== ROUND 1 FINDINGS ===
[Round 1 results from all roles]

=== FIXES APPLIED ===
[git diff of fixes]

=== UPDATED FILES ===
[Current state of changed files]

Your job:
1. Verify each Round 1 FAIL was actually fixed (not just papered over)
2. Check if any fix introduced a NEW issue
3. Review items that were WARN in Round 1 — are they resolved?
4. Look for issues Round 1 missed entirely

Same format: PASS / FAIL / WARN for each item. Be harder this round — Round 1 caught the obvious stuff, now look for subtle issues.
```

### Round 2 → Self-Correction

Fix any remaining FAIL items. Re-run tests. Commit: `"fix: address Round 2 review feedback"`

### Round 3: Final Verification

This is the sign-off round. Spawn ONE senior reviewer sub-agent that sees the full picture:

```
You are the Senior Reviewer doing a final sign-off on this feature.

=== SPEC ===
[Full spec]

=== ROUND 1 FINDINGS + FIXES ===
[Summary]

=== ROUND 2 FINDINGS + FIXES ===
[Summary]

=== FINAL STATE ===
[git diff from branch start to now — the complete changeset]

Your job:
1. Read the full diff as a cohesive change. Does it make sense as a whole?
2. Are there any architectural concerns that individual role reviews might miss?
3. Does the implementation match the spec's acceptance criteria? Check each one.
4. Any loose ends? TODOs in code? Commented-out blocks? Debug logs?
5. Is the code production-ready?

Verdict: SHIP IT / NEEDS WORK (with specific items)
```

If the verdict is NEEDS WORK, fix the items and re-run Round 3 (but don't loop more than once — if it still has issues after a second Round 3, flag them for the human).

## Step 5: Feature Enhancement Round

After the code is solid and reviews pass, step back and ask: "Is this the best version of this feature we can ship?" This step surfaces improvements you wouldn't find in a code review — because it comes from the perspective of people who will actually use it.

### 5a. Customer-Perspective Improvement Suggestions

Generate 5 concrete ways to improve the feature. These aren't bug fixes — they're enhancements that would make real users happier, the feature stickier, or the experience more delightful.

For each suggestion, write a 2-3 sentence description and a rough effort estimate (hours, not days).

Then spawn 5 sub-agents in parallel, each roleplaying a different target customer persona (use the project config's target user archetypes if available, otherwise invent realistic ones). Each receives:

```
You are [PERSONA: e.g., "a vibe-coder who uses Claude to build side projects and delegates micro-tasks via MCP"]. You've just heard about this feature:

=== FEATURE SUMMARY ===
[What was built, in plain language — not code details]

=== 5 PROPOSED IMPROVEMENTS ===
[The 5 suggestions with descriptions]

React as this persona would:
- Which improvement matters MOST to you and why? (rank all 5)
- Which improvement would you NEVER use? Why?
- Is there a 6th improvement none of these capture that you'd actually want?
- Would this feature, as shipped, make you use the platform more? Be honest.

Stay in character. Be specific about your workflow and how this fits (or doesn't).
150-200 words max.
```

Compile the results into a ranked list. The improvement that the most personas ranked #1 is the winner. Present the top 2-3 improvements to the human with the persona reactions.

**If the human approves changes:** implement them, then re-run the dev team review (Round 1 only — focused on the new changes). Commit as: `"enhance: [description] based on customer feedback simulation"`

**If the human says ship as-is:** proceed to Step 5b.

### 5b. Visual Previews

Create visual artifacts so the human (and their CTO/team) can see what was built without reading code.

**If the feature has frontend changes — create an HTML preview:**

Build a standalone `.html` file (save to the project's output/specs directory) that shows:
- Screenshots or mockups of the new UI components (use HTML/CSS to recreate the key screens)
- Before/after comparison if modifying existing UI
- Interactive elements where possible (e.g., a simulated rate limit counter, a mock jury voting flow)
- Mobile and desktop views side by side

Use Tailwind CDN for styling. The preview should look polished — this is what the CTO sees.

**If the feature has backend/API changes — create an HTML schema preview:**

Build a standalone `.html` file that visualizes:
- New data models as an entity-relationship diagram (use SVG or a simple visual layout)
- API endpoint map: method, path, auth required, request/response shapes
- State machine diagram for any status flows (e.g., Dispute lifecycle)
- Rate limit tiers table if applicable

Use clean typography, color coding, and collapsible sections. This is a living API doc, not a wall of text.

**Save previews to:** `specs/previews/XX-feature-name-preview.html` (frontend) and/or `specs/previews/XX-feature-name-schema.html` (backend)

### 5c. CTO Overview Infographic

Create a single-page HTML infographic (`specs/previews/XX-feature-name-overview.html`) designed for a CTO or technical lead who needs to understand what was added in 60 seconds. This is NOT a code review — it's a visual executive summary.

The infographic should include:

1. **Feature title + one-line description** (big, bold, top of page)
2. **Key metrics strip** — 3-4 numbers that matter (e.g., "10x rate limits", "22 new tests", "3 new API endpoints", "0 breaking changes")
3. **What changed** — visual before/after (use icons, diagrams, not prose)
4. **Data model changes** — simple box diagram showing new/modified models and relationships
5. **Risk assessment** — green/yellow/red indicators for: breaking changes, security impact, performance impact, deployment complexity
6. **Dependencies** — which other features this connects to (from the spec's dependency section)
7. **Timeline** — when this ships relative to other features in the roadmap

Style: dark theme, clean typography, professional. Use Tailwind CDN. Think "Stripe dashboard" not "academic paper." The CTO should be able to forward this to their team as a status update.

### 5d. Real-World Action Suggestions

The feature is built — now what? Code alone doesn't create value. Spawn 4 sub-agents in parallel to suggest concrete real-world actions that maximize this feature's impact, each for a different budget scope:

```
You are a [ROLE] advisor for a startup that just shipped this feature:

=== FEATURE ===
[Feature summary]

=== PRODUCT CONTEXT ===
[From project config: business model, target users, competitors, stage]

=== YOUR BUDGET SCOPE ===
[One of: $0 (guerrilla), $100/month (bootstrap), $1000/month (growth), $5000+/month (scale)]

Suggest 3-5 specific, actionable things the team should do NOW to maximize the impact of this feature. These can include:

- Marketing actions (social posts, blog articles, community engagement, PR)
- Sales actions (outreach to specific customer segments, partnership pitches)
- Product actions (landing page changes, onboarding updates, feature flags)
- Community actions (Discord announcements, Twitter threads, demo videos)
- Data actions (analytics setup, A/B tests, user interviews)

Rules:
- Be SPECIFIC. Not "do marketing" — say "Post a Twitter thread showing a before/after of the rate limit change with a GIF of an agent posting 10 jobs in 10 seconds"
- Every suggestion must be doable THIS WEEK
- Include the expected outcome ("This should generate ~X impressions / Y signups / Z conversations")
- Stay within your budget scope

200-300 words max.
```

Compile results into a single action plan organized by budget tier. Present to the human as a table:

| Budget | Action | Expected Outcome | Effort |
|--------|--------|-------------------|--------|
| $0 | ... | ... | 2 hours |
| $100/mo | ... | ... | 1 day |
| ... | ... | ... | ... |

---

## Step 5e: War Room Stress Test (for high-risk features)

If the feature is high-risk — touches payments, auth, data integrity, or is the keystone feature other specs depend on — invoke the `/war` skill (if available) to stress-test the implementation before shipping.

**Trigger criteria (any 2+ = high-risk):**
- Touches money/payments
- Modifies auth or middleware chain
- Adds new database models that other specs depend on
- Changes rate limiting or access control
- Has "breaking changes" in the risk assessment
- Is Phase 1 in the build order (other features depend on it)

**What to send to the war room:**

```
Stress-test this feature implementation:

FEATURE: [name]
SPEC: [key acceptance criteria]
CHANGES: [git diff summary — new models, endpoints, middleware changes]
RISK AREAS: [payment flow / auth / data integrity / performance — whichever apply]

Key questions:
1. What failure modes can this introduce in production?
2. Is the migration reversible? What happens if we need to rollback?
3. Are there race conditions in the new code paths?
4. Does this change break any existing API contracts?
5. What's the worst-case scenario if this feature has a bug?
```

If the war room returns "GO WITH CHANGES" or "NO-GO" items, address them before proceeding. Commit fixes as: `"fix: address war room findings"`.

## Step 5f: Auto-Changelog & Release Notes

Generate release communication artifacts so the team doesn't have to write them manually.

1. **CHANGELOG entry** — Append to the project's CHANGELOG.md (or create one). Follow [Keep a Changelog](https://keepachangelog.com/) format:
   ```markdown
   ## [Unreleased]
   ### Added
   - [Feature]: One-line description (#Linear-issue if available)
   ### Changed
   - [What existing behavior changed]
   ### Fixed
   - [Any bugs fixed as side effects]
   ```

2. **Developer release note** — A 1-paragraph technical summary for the engineering team. What changed, why, what to watch for. Save as `specs/release-notes/XX-feature-name.md`.

3. **User-facing release note** — A 1-paragraph non-technical summary for end users / the blog. Focus on the benefit, not the implementation. Include in the same release notes file under a `## User-Facing` header.

## Step 5g: Stress & Load Testing Suggestions

For any feature that adds API endpoints or changes database queries, generate a load testing plan:

1. **Identify hot paths** — Which new endpoints will get the most traffic? Which queries are called inside loops?
2. **Suggest k6/Artillery test scenarios** — Write sample load test scripts (don't run them, just generate):
   ```javascript
   // Example k6 scenario for the new endpoint
   import http from 'k6/http';
   export const options = { vus: 50, duration: '30s' };
   export default function() {
     http.get('http://localhost:3000/api/endpoint');
   }
   ```
3. **Estimate capacity** — Based on the query complexity and DB operations, estimate: "This endpoint should handle ~X req/s on a single Postgres instance."
4. **Flag N+1 queries** — Check for any loops that issue individual DB queries instead of batch operations.

Save the load test file to `specs/load-tests/XX-feature-name.k6.js` (even if it won't be run in CI — it's documentation of expected load patterns).

## Step 5h: Monitoring Dashboard

Every feature ships with a monitoring dashboard — no exceptions. Read the `feature-monitor` skill at `.claude/skills/feature-monitor/SKILL.md` and follow its steps, but **skip Step 1 (Feature Audit)** — you already have all the inputs from earlier phases. Instead, feed the audit answers directly from your spec-dev work:

### Mapping spec-dev artifacts → feature-monitor inputs

| feature-monitor expects | you already have it from |
|---|---|
| **1a. Feature Identity** — what is it, who uses it, happy path, failure modes | The spec's intro section + acceptance criteria |
| **1b. Success Criteria** — what "working" and "broken" look like | The spec's acceptance criteria + the post-deploy monitoring checklist you generated in Step 6 |
| **1c. Data Sources — events** | Phase G's observability events (the 3-5 analytics events you added) |
| **1c. Data Sources — tables/columns** | Phase A's data model (new Prisma models and columns) |
| **1c. Data Sources — errors** | Phase G's error handling (every catch block you added with context) |

Start feature-monitor at **Step 2 (Metric Design)** with these pre-filled inputs. Then continue through its Steps 3-7 normally.

### Tier-specific behavior

| Tier | What to build |
|---|---|
| **Light** | Write only the Feature Audit answers (formatted per feature-monitor's template) + metric definitions as a markdown file at `specs/monitoring/XX-feature-name-metrics.md`. Add a stub admin API endpoint that returns empty data in the right shape. The full dashboard can be built later by running feature-monitor standalone. |
| **Standard** | Build the full dashboard: backend endpoint(s) with real queries, frontend component with KPI cards + 1-2 charts, tests. Follow feature-monitor Steps 2-7. |
| **Heavy** | Full dashboard + segment breakdowns by user tier (BASIC/PRO/WHALE or equivalent). Add drill-down views if the feature has a multi-step flow (e.g., dispute lifecycle stages). Follow feature-monitor Steps 2-7 completely. |

### Where it lives

Add the dashboard as a new tab or section in the existing admin panel. Follow the same component structure, auth pattern, and shared helpers as existing admin dashboard sections — read 1-2 existing sections first to match the pattern.

Commit the monitoring code as: `"feat: add monitoring dashboard for [feature-name]"`

## Step 6: Final Verification

After the enhancement round (and any approved improvements are implemented):

1. **Run the full test suite** one final time
2. **Run the build** (TypeScript compilation, etc.)
3. **Check git status** — working tree should be clean (all changes committed)
4. **Verify branch** — confirm you're on the feature branch, not main
5. **Run through acceptance criteria** from the spec — every single one must be met
6. **Check layer sync** — one last pass on the project config's sync rules

### Cross-Feature Regression Check

If other feature branches are in flight (check with `git branch --list 'session/*'`), verify this implementation won't conflict:

1. **Shared file check** — List files this branch modifies. Compare against other active branches' changes (`git diff main..session/other-branch --name-only`). Flag any overlapping files.
2. **Schema conflicts** — If you added a Prisma migration, check that its number/name won't collide with migrations on other branches.
3. **Route conflicts** — If you added new API routes, verify no other branch adds the same paths.
4. **Enum conflicts** — If you added new enum values, check that other branches aren't adding different values to the same enum.

Document any potential conflicts in the completion report so the human can merge branches in the right order.

### Post-Deploy Monitoring Checklist

Generate a checklist of things to watch AFTER this feature goes to production. The human should check these within 24 hours of deploy:

- [ ] **Error rate** — Is the error rate for new endpoints < 1%?
- [ ] **Latency** — Are new endpoints responding within acceptable thresholds (< 200ms p95)?
- [ ] **Database** — Are new queries performing as expected? Any slow query alerts?
- [ ] **Rate limits** — Are the new limits being hit? By whom? Expected behavior?
- [ ] **Feature flag** — Is the flag on/off as intended? Can it be toggled without a deploy?
- [ ] **Cron jobs** — If added, are they running on schedule? Check logs.
- [ ] **Edge cases** — Test the top 3 edge cases from the QA review manually in production.
- [ ] **User feedback** — Any support tickets or complaints related to the new feature?

Save this as `specs/monitoring/XX-feature-name-monitoring.md`.

### Completion Checklist

- [ ] Feature branch created (not on main/master)
- [ ] All code changes committed to feature branch
- [ ] Build passes (no compilation errors)
- [ ] All tests pass (existing + new)
- [ ] New test file(s) created per spec
- [ ] Dev Team Review completed (3 rounds, all FAIL items resolved)
- [ ] Enhancement round completed (5a-5h)
- [ ] Acceptance criteria from spec all met
- [ ] Layer sync verified (schema ↔ validation ↔ types ↔ API client)
- [ ] No hardcoded secrets or .env files committed
- [ ] No TODO/FIXME/HACK comments left unaddressed
- [ ] No console.log or debug statements left in
- [ ] Cross-feature regression check done (if other branches active)
- [ ] Post-deploy monitoring checklist generated
- [ ] CHANGELOG.md updated
- [ ] Git status shows clean working tree
- [ ] Branch NOT pushed to remote (human reviews first)

## Step 7: Report to Human

Present a concise summary with links to all generated artifacts. The TL;DR is the most important part — many readers won't scroll past it.

**For Light tier:** Only include the TL;DR, Files Changed, Tests, and Acceptance Criteria sections.
**For Standard tier:** Include everything except War Room and Cross-Feature Notes (unless relevant).
**For Heavy tier:** Include everything.

```
## Feature Complete: [Feature Name]

> **TL;DR:** [One sentence: what changed.] [One sentence: what to watch.] [One sentence: what to do next.]
>
> Example: "Rate limits upgraded to 10/100/500 per tier with 24h sliding windows. Watch for agents hitting new WHALE tier limits in the first week. Merge branch, enable FEATURE_RATE_LIMITS_V2=true, monitor /health/rate-limits."

**Branch:** session/YYYYMMDD-HHMMSS-feature-name
**Spec:** specs/XX-feature-name.md
**Tier:** [Light / Standard / Heavy]
**Linear:** [Link to parent issue] (if Linear tracking was created)
**Duration:** [time from branch creation to completion]

### What Was Built
[2-3 sentences — skip if TL;DR covers it for Light tier]

### CHANGELOG
[Paste the CHANGELOG entry here so the human can review it inline]

### Files Changed
- **New:** [list of new files created, grouped by purpose]
- **Modified:** [list of existing files modified]
- **Migrations:** [list of new migrations, if any]

### Tests
- X new tests written (file: `backend/src/tests/XX.test.ts`)
- All Y tests passing
- Estimated load capacity: ~Z req/s (from Step 5g)

### Dev Team Review
- Round 1: X issues found, X fixed
- Round 2: X issues found, X fixed
- Round 3: SHIP IT ✓
- War Room: [PASS / triggered with findings / not triggered] (from Step 5e)

### Customer Enhancement Round
- Top improvement: [description] — [implemented / deferred per human decision]
- Personas consulted: [list of 5 personas and their top pick]

### Previews & Artifacts
- [Frontend Preview](specs/previews/XX-feature-name-preview.html) (if applicable)
- [Schema Preview](specs/previews/XX-feature-name-schema.html) (if applicable)
- [CTO Overview](specs/previews/XX-feature-name-overview.html)
- [Release Notes](specs/release-notes/XX-feature-name.md)
- [Monitoring Checklist](specs/monitoring/XX-feature-name-monitoring.md)
- [Monitoring Dashboard] — admin component at `/dev/admin` → Feature section
- [Load Test](specs/load-tests/XX-feature-name.k6.js) (if applicable)

### Real-World Action Plan
[Top 3 actions across budget tiers, as a quick table]

### Acceptance Criteria
- [✓] Criterion 1
- [✓] Criterion 2
- [✓] ...

### Decisions Made
[Any ambiguity resolved during implementation — what was decided and why]

### Cross-Feature Notes
[Any potential conflicts with other active branches, merge order recommendations]

### Feature Flag
- Flag name: `FEATURE_XX_ENABLED`
- Default: `false` (off until explicitly enabled)
- Rollback: [what happens when turned off]

### Ready for your review. Branch is NOT pushed.
```

---

## Handling Spec Dependencies

If the spec lists dependencies on other specs (e.g., "Depends on: 01-rate-limits"), check whether those features are already merged to master:

- **If merged:** Your branch already has them. Proceed normally.
- **If not merged:** Implement only the parts that don't depend on the missing feature. Add TODO comments at integration points: `// TODO: Wire to jury system when spec-02 is merged`. Document what's deferred in your completion report.

## Handling Ambiguity

If the spec is unclear on something:

1. Check the project config's codebase rules file
2. Check existing code for similar patterns
3. If still unclear, make the most reasonable choice and document it in a code comment: `// DECISION: Chose X over Y because [reason]. Revisit if spec clarifies.`
4. Flag it in the completion report under "Decisions Made"

Do NOT ask the human to clarify unless it's a fundamental architectural question that would require reworking everything if you guess wrong.
