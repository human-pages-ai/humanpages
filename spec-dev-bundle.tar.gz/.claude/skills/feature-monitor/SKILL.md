---
name: feature-monitor
description: >
  Build comprehensive admin monitoring dashboards for any product feature — active users,
  engagement metrics, conversion rates, usage patterns, or health indicators. Use this skill
  whenever the user mentions feature monitoring, admin dashboard, admin panel, usage metrics,
  engagement tracking, product analytics dashboard, DAU/WAU/MAU charts, retention metrics,
  feature health monitoring, or wants to build an internal tool to understand how a feature
  is performing. Also trigger when the user says "track usage", "monitor feature", "build
  admin metrics", "add analytics dashboard", "how is X performing", or anything about
  measuring adoption, engagement, or health of a product feature — even if they don't
  explicitly say "monitoring" or "dashboard". This skill covers the full stack: defining
  what to measure, backend aggregation, frontend visualization, shared helpers, auth,
  and testing.
---

# Feature Monitor

A systematic approach to building production-grade monitoring for any product feature.
Where the wizard-monitor skill handles multi-step sequential flows, this skill handles
the more general case: any feature where you need to understand adoption, engagement,
value delivery, and health.

The approach was extracted from building monitoring across an admin dashboard covering
user onboarding, vouch systems, payment flows, active user tracking, and signup funnels.

## Philosophy

Every feature monitoring dashboard should answer five questions:

1. **Adoption**: How many users are using this feature? Is it growing?
2. **Engagement**: How actively are they using it? (frequency, depth, recency)
3. **Value**: Is the feature delivering the outcome it was designed for?
4. **Health**: Are there errors, slowdowns, or degradations?
5. **Segments**: Do different user cohorts behave differently?

Not every feature needs all five. A simple feature might only need adoption + value.
A complex feature might need all five with drill-downs. Use judgment based on the feature's
importance and complexity.

## Architecture: The Three-Layer Pattern

Every feature monitor follows the same three-layer architecture:

```
┌─────────────────────────────────────────────────────────┐
│  Layer 1: METRIC DEFINITION                             │
│  "What do we measure and why?"                          │
│  ├── Adoption metrics (counts, rates, growth)           │
│  ├── Engagement metrics (frequency, depth, time)        │
│  ├── Value metrics (outcomes, conversions, quality)     │
│  └── Health metrics (errors, latency, degradation)      │
├─────────────────────────────────────────────────────────┤
│  Layer 2: DATA COLLECTION                               │
│  "Where does the data come from?"                       │
│  ├── Analytics events (PostHog, Amplitude, etc.)        │
│  ├── Database queries (Prisma, raw SQL)                 │
│  ├── Infrastructure metrics (logs, APM)                 │
│  └── Derived/computed metrics (ratios, composites)      │
├─────────────────────────────────────────────────────────┤
│  Layer 3: VISUALIZATION                                 │
│  "How do humans consume this?"                          │
│  ├── KPI cards (current state at a glance)              │
│  ├── Time-series charts (trends, patterns)              │
│  ├── Breakdown tables (segments, cohorts)               │
│  └── Alerts/thresholds (when things go wrong)           │
└─────────────────────────────────────────────────────────┘
```

## Step 1: Feature Audit

Before writing any code, answer these questions about the feature you're monitoring.
Read `references/feature-audit-template.md` for a fillable template.

### 1a. Feature Identity
- What is the feature? (one sentence)
- Who uses it? (user type / persona)
- What's the happy path? (user does X → Y happens)
- What can go wrong? (failure modes)

### 1b. Success Criteria
- What does "working well" look like? (quantitative)
- What does "broken" look like? (thresholds)
- What would a PM check weekly? What would an engineer check during an incident?

### 1c. Data Sources
- What events does the feature fire? (analytics)
- What tables/columns does it write? (database)
- What errors does it produce? (logs/APM)

## Step 2: Metric Design

Design metrics across four categories. Not every feature needs all categories —
pick what's relevant.

### Adoption Metrics
These answer "is anyone using this?"

| Metric | Query pattern | Visualization |
|---|---|---|
| Total users | `COUNT(DISTINCT user_id) WHERE feature_used = true` | KPI card |
| New users (7d/30d) | `COUNT WHERE created_at > now() - 7d` | KPI card with trend |
| DAU/WAU/MAU | Time-windowed distinct active users | Interactive chart with aggregation toggle |
| Adoption rate | `feature_users / total_users` | KPI card with color threshold |
| Growth rate | Period-over-period comparison | Trend arrow on KPI card |

### Engagement Metrics
These answer "how much are they using it?"

| Metric | Query pattern | Visualization |
|---|---|---|
| Actions per user | `COUNT(events) / COUNT(DISTINCT users)` | KPI card |
| Session depth | Average events per session | Time-series chart |
| Return rate | Users active in >1 period / total active | KPI card (stickiness) |
| Time spent | Median/avg duration between start→end events | Bar chart per sub-feature |
| DAU/WAU ratio | Stickiness indicator | KPI card |

### Value Metrics
These answer "is it delivering results?" This is the most important and hardest category.

| Metric | Query pattern | Visualization |
|---|---|---|
| Conversion rate | `completed / started` | KPI card with threshold |
| Outcome count | DB records created by the feature | KPI card |
| Quality score | Composite of sub-values | Progress bar with breakdown |
| Revenue/volume | Sum of payments, transactions | KPI card with trend |

### Health Metrics
These answer "is anything broken?"

| Metric | Query pattern | Visualization |
|---|---|---|
| Error rate | `errors / total_requests` | KPI card (red when > threshold) |
| P50/P95 latency | Percentile aggregation | Time-series chart |
| Failure modes | Grouped error counts | Table |

## Step 3: Build the Active Users Chart Pattern

Almost every feature dashboard needs an active users chart. This is a reusable pattern.

Read `references/active-users-chart.md` for the complete implementation including:
- Daily/Weekly/Monthly aggregation toggle
- Range selector (7d/14d/30d/60d/90d)
- Stacked bars (new signups + returning) with line overlay (total active)
- KPI row: DAU, WAU, MAU, Avg Daily Active (with trend), Retention Rate
- Week-aligned bucketing (Monday start)
- Period-over-period trend calculation

Key design decisions:
- **Use full words**, not abbreviations. "Daily Active Users" not "DAU".
- **Day-level granularity** with aggregation in the frontend, not pre-aggregated on backend.
- **Stacked bars** decompose "where do active users come from?" (new vs returning).
- **Line overlay** shows the total, making it easy to spot trends even when composition changes.

## Step 4: Build the Backend

### Endpoint Pattern

One endpoint per feature section, returning everything the frontend needs:

```typescript
router.get('/stats/<feature>', async (req, res) => {
  try {
    const [metricA, metricB, metricC] = await Promise.all([
      // Analytics queries (PostHog/etc.)
      queryAnalytics(`SELECT ...`),
      // Database queries (Prisma)
      prisma.user.count({ where: { ... } }),
      // Raw SQL for complex aggregations
      prisma.$queryRaw<{ result: number }[]>`SELECT ...`,
    ]);

    res.json({ metricA, metricB, metricC });
  } catch (error) {
    logger.error({ err: error }, 'Feature stats error');
    res.status(500).json({ error: 'Internal server error' });
  }
});
```

### Performance Pattern

Batch all independent queries with `Promise.all`. This is critical — 30 sequential
Prisma queries take ~3s, but parallelized they take ~100ms.

### Auth Pattern

Apply authentication middleware at the router level, not per-route:

```typescript
// In the admin router file
router.use(authenticateToken, requireAdmin);
// Everything below is admin-only
```

Never rely on frontend-only auth. The backend must reject unauthorized requests.

### Analytics Proxy Pattern

If you use PostHog or similar, proxy queries through your backend:

```typescript
// Server-side only — API key never reaches client
const { queryPostHog } = await import('../lib/posthog-query.js');
const result = await queryPostHog(`SELECT ... FROM events WHERE ...`);
```

Add query validation to prevent injection. See `references/security-patterns.md`.

## Step 5: Build the Frontend

### Shared Helpers

Read `references/shared-helpers.md` for the full set of helpers to extract into a shared file.
These prevent duplication across dashboard components:

- `fmt()` — locale-formatted numbers
- `pct()`, `pctStr()` — percentage calculations
- `formatDate()` — ISO date → "Mar 5"
- `safeDiv()` — division that handles zero
- `rollingAvg()` — smoothing for time series
- `delta()` — period-over-period trend
- `formatDuration()` — seconds → "2m 30s"

### Component Structure

Each feature monitor component follows this layout:

```
┌──────────────────────────────────────────────────────┐
│ Header: Feature Name          [View Tabs] [Controls] │
├──────────────────────────────────────────────────────┤
│ KPI Row: 4-6 cards with key numbers                  │
├──────────────────────────────────────────────────────┤
│ Main Visualization: chart / table / breakdown        │
│ (changes based on selected tab)                      │
└──────────────────────────────────────────────────────┘
```

### Visualization Selection Guide

| Data type | Best visualization |
|---|---|
| Single number + trend | KPI card with trend arrow |
| Time series (1-2 metrics) | Line chart |
| Time series (3+ metrics) | ComposedChart (bars + lines) |
| Categorical breakdown | Horizontal bar chart |
| Part-of-whole | Stacked bars or progress bar |
| Ranking / comparison | Horizontal bars sorted by value |
| Funnel / conversion | Funnel bars (light=entered, solid=converted) |

### Color Thresholds

Use consistent color coding for health:
```typescript
const accent = value >= goodThreshold
  ? 'text-green-600'
  : value >= warnThreshold
  ? 'text-yellow-600'
  : 'text-red-500';
```

### Recharts Best Practices

- Always wrap in `<ResponsiveContainer width="100%" height="100%">`
- Use `ComposedChart` when mixing bars and lines
- Custom tooltips are worth the effort — they look much better than defaults
- Set `barSize` based on data density: 20px for ≤14 points, 12px for ≤30, 6px for more
- Use `interval="preserveStartEnd"` on XAxis to avoid overcrowded labels
- Color palette: blue (#3b82f6), purple (#8b5cf6), cyan (#06b6d4), green (#22c55e), orange (#f97316), pink (#ec4899), yellow (#eab308)

## Step 6: Tests

Every feature monitor needs these test categories:

1. **Renders when data loads** — basic smoke test
2. **KPIs show correct labels** — verify all KPI cards appear
3. **Controls work** — tabs switch, aggregation toggles, range selectors
4. **Graceful degradation** — API failure doesn't break the rest of the page
5. **Edge cases** — empty data, zero values, missing optional fields

Mock pattern:
```typescript
const mockGetFeatureStats = vi.fn();
vi.mock('../lib/api', () => ({
  api: { getFeatureStats: () => mockGetFeatureStats() },
}));

beforeEach(() => {
  mockGetFeatureStats.mockResolvedValue({ /* realistic mock data */ });
});
```

## Step 7: DRY Checklist

Before shipping, verify:

- [ ] No duplicate helper functions across components (use shared helpers file)
- [ ] No hardcoded magic numbers (extract to named constants)
- [ ] No `any` types (use proper interfaces)
- [ ] All endpoints protected by admin auth middleware
- [ ] Analytics API keys never reach the client
- [ ] All queries validated if accepting dynamic parameters
- [ ] KPI labels use full words, not abbreviations
- [ ] Charts have interactive controls (range, aggregation)
- [ ] Component handles loading, error, and empty states
- [ ] Tests cover happy path, API failure, and edge cases
