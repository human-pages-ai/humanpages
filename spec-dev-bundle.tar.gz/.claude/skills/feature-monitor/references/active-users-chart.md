# Active Users Chart — Complete Implementation Pattern

This is the most common feature monitor component: an interactive active users chart with
aggregation controls. It replaces static DAU/WAU/MAU cards with a real explorable chart.

## Data Requirements

The backend needs to provide two day-level time series:

```typescript
interface UsageData {
  dau: number;              // Today's active users
  wau: number;              // This week's active users
  mau: number;              // This month's active users
  dauWauRatio: number;      // Stickiness (%)
  retentionRate: number;    // Returning users / previous period active (%)
  returningUsers: number;   // Users active this week who were also active last week
  activeByDay: { day: string; count: number }[];   // Daily active user counts
  signupsByDay: { day: string; count: number }[];   // Daily new signup counts
}
```

Both series should go back at least 90 days to support the full range selector.

## Component Design

### Controls
- **Aggregation toggle**: Daily | Weekly | Monthly
- **Range selector**: 7d | 14d | 30d | 60d | 90d

### KPI Row (5 cards)
1. Daily Active Users — today's count, label "Today"
2. Weekly Active Users — with stickiness ratio
3. Monthly Active Users — with "X% of all users"
4. Avg Daily Active — computed from selected range, with period-over-period trend
5. Retention Rate — with returning user count, color-coded threshold

### Chart
- **Stacked bars**: New Signups (purple, light) + Returning Users (blue, light)
- **Line overlay**: Total Active Users (cyan, solid)
- The bars decompose the line — signups + returning = active

### Aggregation Logic

**Daily**: Pass through as-is.

**Weekly** (Monday-aligned):
```typescript
const dayOfWeek = d.getDay();
const mondayOffset = dayOfWeek === 0 ? -6 : 1 - dayOfWeek;
const monday = new Date(d);
monday.setDate(d.getDate() + mondayOffset);
```

**Monthly**: Group by `YYYY-MM-01`.

For weekly/monthly, values are summed within the bucket. The chart shows the aggregated totals.

### Period-over-Period Trend

Split the selected range in half and compare:
```typescript
const half = Math.floor(sliced.length / 2);
const recent = sliced.slice(half).reduce((s, r) => s + r.activeUsers, 0);
const prior = sliced.slice(0, half).reduce((s, r) => s + r.activeUsers, 0);
const trend = prior > 0
  ? Math.round(((recent - prior) / prior) * 100)
  : recent > 0 ? 100 : 0;
```

Display as an up/down arrow with percentage on the Avg Daily Active KPI card.

### Bar Size Adaptation

Adjust bar width based on how many data points are visible:
```typescript
barSize={chartData.length <= 14 ? 20 : chartData.length <= 30 ? 12 : 6}
```

### XAxis Interval
```typescript
interval={data.length <= 14 ? 0 : data.length <= 30 ? 'preserveStartEnd' : Math.floor(data.length / 8)}
```

## Backend Queries

### Active users per day (PostHog)
```sql
SELECT
  toDate(timestamp) AS day,
  count(DISTINCT distinct_id) AS count
FROM events
WHERE timestamp >= now() - INTERVAL 90 DAY
  AND event IN ('$pageview', '$screen')
GROUP BY day
ORDER BY day
```

### Active users per day (Prisma)
```typescript
const activeByDay = await prisma.$queryRaw<{ day: string; count: number }[]>`
  SELECT DATE("lastActiveAt") AS day, COUNT(*)::int AS count
  FROM "User"
  WHERE "lastActiveAt" >= NOW() - INTERVAL '90 days'
  GROUP BY day
  ORDER BY day
`;
```

### Signups per day
```typescript
const signupsByDay = await prisma.$queryRaw<{ day: string; count: number }[]>`
  SELECT DATE("createdAt") AS day, COUNT(*)::int AS count
  FROM "User"
  WHERE "createdAt" >= NOW() - INTERVAL '90 days'
  GROUP BY day
  ORDER BY day
`;
```

### DAU/WAU/MAU
```typescript
const [dau, wau, mau] = await Promise.all([
  prisma.user.count({ where: { lastActiveAt: { gte: startOfToday } } }),
  prisma.user.count({ where: { lastActiveAt: { gte: startOfWeek } } }),
  prisma.user.count({ where: { lastActiveAt: { gte: startOfMonth } } }),
]);
```

### Retention (returning users)
```typescript
const returningUsers = await prisma.$queryRaw<{ count: number }[]>`
  SELECT COUNT(*)::int AS count FROM "User"
  WHERE "lastActiveAt" >= ${startOfThisWeek}
    AND "lastActiveAt" < ${endOfThisWeek}
    AND "createdAt" < ${startOfThisWeek}
`;
```

## Key Design Decisions

1. **Full words, not abbreviations**. "Daily Active Users" not "DAU". Abbreviations save 3 characters and cost comprehension for anyone not steeped in analytics jargon.

2. **Day-level granularity, frontend aggregation**. The backend sends daily data. The frontend aggregates to weekly/monthly. This means one API call supports all views, and the user can switch instantly without a new request.

3. **Returning = Active - Signups**. This is an approximation: `returning ≈ active - newSignups`. It's close enough for a dashboard and avoids a complex cohort query.

4. **Monday-aligned weeks**. Business weeks start on Monday. Sunday-start weeks split weekends, which makes the data harder to interpret.
