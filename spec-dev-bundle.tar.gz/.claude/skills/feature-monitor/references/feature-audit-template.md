# Feature Audit Template

Fill this out before writing any monitoring code. It forces you to think through what matters before building.

## Feature Identity

**Feature name**: ___

**One-sentence description**: ___

**Primary user**: ___ (e.g., "service providers signing up", "agents hiring humans", "admins reviewing reports")

**Happy path**:
1. User does ___
2. System does ___
3. Outcome: ___

**Failure modes**:
- ___ (e.g., "user abandons halfway", "API call fails", "data doesn't persist")
- ___
- ___

## Success Criteria

**"Working well" means**:
- [ ] ___ (quantitative — e.g., ">80% completion rate")
- [ ] ___ (e.g., "<5% error rate")
- [ ] ___ (e.g., "P95 latency <2s")

**"Broken" means**:
- [ ] ___ (red alert — e.g., "error rate >20%")
- [ ] ___ (e.g., "zero completions for 1 hour")

**PM weekly check**: ___

**Engineer incident check**: ___

## Data Sources

### Analytics Events
| Event name | Properties | When fired |
|---|---|---|
| `feature_started` | `{ }` | User begins the feature |
| `feature_completed` | `{ result: string }` | User finishes |
| `feature_error` | `{ error: string }` | Something failed |

### Database Tables
| Table | Relevant columns | What it represents |
|---|---|---|
| `User` | `featureEnabledAt`, `featureCount` | Feature adoption |
| `FeatureRecord` | `status`, `createdAt`, `userId` | Feature usage |

### Derived Metrics
| Metric | Formula | Why it matters |
|---|---|---|
| Adoption rate | `users_with_feature / total_users` | Are users finding this? |
| Completion rate | `completed / started` | Is it usable? |
| Value score | `successful_outcomes / completions` | Is it delivering? |

## Metric Categories

Check which categories apply to this feature:

- [ ] **Adoption** — counts, rates, growth
- [ ] **Engagement** — frequency, depth, return rate
- [ ] **Value** — outcomes, conversions, quality
- [ ] **Health** — errors, latency, degradation
- [ ] **Segments** — cohort differences

## Composite Goal

The one metric that answers "is this feature working?":

**Name**: ___
**Definition**: ___
**Formula**: ___
**Threshold**: good = ___, warning = ___, bad = ___

## Visualization Plan

| Metric | Visualization | Priority |
|---|---|---|
| ___ | KPI card | Must have |
| ___ | Time-series chart | Must have |
| ___ | Breakdown bars | Nice to have |
| ___ | Table | Nice to have |
