# Shared Dashboard Helpers

These helpers should be extracted into a single shared file (e.g., `adminHelpers.ts`) and imported
by all dashboard components. This prevents the #1 dashboard codebase problem: duplicated formatting
functions across 5+ files that slowly drift out of sync.

## Complete Implementation

```typescript
/**
 * Shared helpers for admin dashboard components.
 * Centralises formatting / math utilities so they aren't duplicated.
 */

/** Locale-formatted integer (e.g. 1,234) */
export function fmt(n: number): string {
  return n.toLocaleString();
}

/** Percentage as integer (0-100). Returns 0 when whole is 0. */
export function pct(part: number, whole: number): number {
  if (whole === 0) return 0;
  return Math.round((part / whole) * 100);
}

/** Percentage with one decimal place, returned as string (e.g. "12.3"). */
export function pctStr(part: number, whole: number): string {
  if (whole === 0) return '0';
  return (Math.round((part / whole) * 1000) / 10).toFixed(1);
}

/** Format an ISO date string as "Mar 5" etc. */
export function formatDate(day: string): string {
  const d = new Date(day + 'T00:00:00');
  return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
}

/** Safe division — returns 0 when divisor is 0. One decimal place. */
export function safeDiv(a: number, b: number): number {
  return b > 0 ? Math.round((a / b) * 1000) / 10 : 0;
}

/** Compute a rolling average over a given window size. */
export function rollingAvg(arr: number[], window: number): number[] {
  return arr.map((_, i) => {
    const start = Math.max(0, i - window + 1);
    const slice = arr.slice(start, i + 1);
    return slice.length > 0
      ? Math.round(slice.reduce((a, b) => a + b, 0) / slice.length * 10) / 10
      : 0;
  });
}

/** Day-over-day delta for trend badges. */
export function delta(
  current: number,
  previous: number
): { pct: number; dir: 'up' | 'down' | 'flat' } {
  if (previous === 0)
    return { pct: current > 0 ? 100 : 0, dir: current > 0 ? 'up' : 'flat' };
  const p = Math.round(((current - previous) / previous) * 100);
  return { pct: Math.abs(p), dir: p > 0 ? 'up' : p < 0 ? 'down' : 'flat' };
}

/** Format seconds as human-readable duration */
export function formatDuration(seconds: number | null): string {
  if (seconds === null || seconds <= 0) return '—';
  if (seconds < 60) return `${seconds}s`;
  if (seconds < 3600) return `${Math.round(seconds / 60)}m`;
  return `${(seconds / 3600).toFixed(1)}h`;
}
```

## Usage Patterns

### In a component that shows counts:
```typescript
import { fmt, pct } from './adminHelpers';
// "1,234 users (45% of total)"
<span>{fmt(count)} users ({pct(count, total)}% of total)</span>
```

### In a component that shows trends:
```typescript
import { delta } from './adminHelpers';
const { pct, dir } = delta(thisWeek, lastWeek);
// "↑ 12%"
<span className={dir === 'up' ? 'text-green-600' : 'text-red-500'}>
  {dir === 'up' ? '↑' : '↓'} {pct}%
</span>
```

### In a chart with tooltips:
```typescript
import { fmt, formatDate } from './adminHelpers';
<XAxis dataKey="day" tickFormatter={formatDate} />
<Tooltip formatter={(v) => fmt(v as number)} />
```

## Why This Matters

In our codebase, before extracting these helpers, we had:
- `fmt()` duplicated in 4 files
- Two slightly different `pct()` implementations (one returning number, one string)
- `formatDate()` in 3 files with the same bug potential

After extraction: one import, one source of truth, zero drift.
