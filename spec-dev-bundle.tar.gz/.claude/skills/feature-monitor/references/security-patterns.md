# Security Patterns for Feature Monitoring

## 1. Admin Auth Enforcement

All monitoring endpoints must be protected at the router level, not per-route:

```typescript
// admin.ts router
import { authenticateToken, requireAdmin } from '../middleware/auth.js';

const router = express.Router();

// Apply ONCE — all routes below require admin
router.use(authenticateToken, requireAdmin);

// These are all admin-only now:
router.get('/stats/overview', async (req, res) => { ... });
router.get('/stats/feature', async (req, res) => { ... });
router.get('/stats/wizard', async (req, res) => { ... });
```

Why router-level, not per-route:
- Per-route auth is easy to forget on new endpoints
- One missing `requireAdmin` call = data leak
- Router-level auth is fail-safe: new routes are protected by default

## 2. Analytics API Key Protection

Never expose PostHog/Amplitude/Mixpanel API keys to the frontend.

**Wrong**: Frontend calls PostHog API directly with key in headers
**Right**: Frontend calls your backend, which proxies to PostHog

```
Frontend → GET /api/admin/stats/wizard → Backend → PostHog API
                                         ↑ API key lives here only
```

Implementation:
```typescript
// posthog-query.ts (server-side only)
export async function queryPostHog(hogql: string): Promise<HogQLResult | null> {
  const apiKey = process.env.POSTHOG_KEY; // Server-side env var
  if (!apiKey) return null;

  const res = await fetch(`${POSTHOG_HOST}/api/projects/${projectId}/query/`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${apiKey}`,
    },
    body: JSON.stringify({ query: { kind: 'HogQLQuery', query: hogql } }),
  });
  // ...
}
```

## 3. Query Injection Prevention

If any part of a query is dynamic (e.g., date ranges, step names), validate it:

### For HogQL/Analytics queries:
```typescript
const BLOCKED_PATTERNS = [
  /;\s*(DROP|DELETE|INSERT|UPDATE|ALTER|CREATE|TRUNCATE)/i,
  /INTO\s+OUTFILE/i,
  /UNION\s+SELECT/i,
  /--\s/,           // Line comments
  /\/\*.*\*\//s,    // Block comments
];

function isQueryAllowed(hogql: string): boolean {
  if (!/^\s*SELECT\s/i.test(hogql)) return false;
  for (const p of BLOCKED_PATTERNS) {
    if (p.test(hogql)) return false;
  }
  return true;
}
```

### For Prisma:
Prisma's query builder is safe by default. Use `prisma.$queryRaw` with tagged template literals for raw SQL:

```typescript
// SAFE — tagged template (parameterized)
prisma.$queryRaw`SELECT * FROM "User" WHERE id = ${userId}`

// UNSAFE — string interpolation
prisma.$queryRawUnsafe(`SELECT * FROM "User" WHERE id = '${userId}'`)
```

Never use `$queryRawUnsafe` with user input.

## 4. Frontend Route Guards (Defense in Depth)

Frontend guards are a UX convenience, not a security boundary. But they're still worth having:

```typescript
// Route guard
<Route path="/admin/*" element={
  user?.role === 'admin' ? <AdminLayout /> : <Navigate to="/" />
} />
```

The backend auth is what actually protects the data. Frontend guards just prevent non-admins from seeing a broken page.

## 5. Data Minimization

Admin endpoints should return aggregated metrics, not raw user data:

```typescript
// Good: aggregate
res.json({ totalUsers: 1234, completionRate: 67.5 });

// Bad: raw data
res.json({ users: [{ email: 'alice@...', actions: [...] }] });
```

If you need to expose individual records (e.g., for debugging), require a separate permission level and log the access.

## Checklist

- [ ] Admin auth middleware applied at router level
- [ ] Analytics API keys in server-side env vars only
- [ ] HogQL queries validated before execution
- [ ] Raw SQL uses tagged templates (parameterized), never string interpolation
- [ ] Frontend route guards present (defense in depth)
- [ ] Admin endpoints return aggregates, not raw PII
- [ ] All admin API calls logged with requesting user
